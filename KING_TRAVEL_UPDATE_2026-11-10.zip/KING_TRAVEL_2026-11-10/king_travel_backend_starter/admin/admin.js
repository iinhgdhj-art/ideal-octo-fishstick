import { firebaseConfig, appCheckSiteKey } from "./firebase-config.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged, signOut, getIdTokenResult } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js";
import { initializeAppCheck, ReCaptchaV3Provider } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app-check.js";
import { getFirestore, collection, getDocs, query, orderBy, limit, where } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-firestore.js";
import { getFunctions, httpsCallable } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-functions.js";

const app = initializeApp(firebaseConfig);
initializeAppCheck(app, { provider: new ReCaptchaV3Provider(appCheckSiteKey), isTokenAutoRefreshEnabled: true });
const auth = getAuth(app);
const db = getFirestore(app);
const functions = getFunctions(app, "europe-west1");
const reviewDriverApplication = httpsCallable(functions, "reviewDriverApplication");
const updateTripStatus = httpsCallable(functions, "updateTripStatus");
const cancelBooking = httpsCallable(functions, "cancelBooking");

const $ = id => document.getElementById(id);
let recaptchaVerifier = null;
let confirmationResult = null;

$("sendCodeBtn").addEventListener("click", async () => {
  try {
    $("loginMessage").textContent = "جارٍ إرسال رمز التحقق…";
    if (!recaptchaVerifier) recaptchaVerifier = new RecaptchaVerifier(auth, "recaptcha-container", { size: "normal" });
    confirmationResult = await signInWithPhoneNumber(auth, $("phoneInput").value.trim(), recaptchaVerifier);
    $("codeWrap").hidden = false;
    $("verifyCodeBtn").hidden = false;
    $("loginMessage").textContent = "أدخل رمز SMS الذي وصلك.";
  } catch (error) { $("loginMessage").textContent = error.message; }
});

$("verifyCodeBtn").addEventListener("click", async () => {
  try {
    if (!confirmationResult) throw new Error("اطلب رمز التحقق أولاً.");
    await confirmationResult.confirm($("codeInput").value.trim());
  } catch (error) { $("loginMessage").textContent = error.message; }
});

$("logoutBtn").addEventListener("click", () => signOut(auth));
$("refreshBtn").addEventListener("click", loadDashboard);

onAuthStateChanged(auth, async user => {
  if (!user) {
    $("loginPanel").hidden = false; $("dashboard").hidden = true; $("logoutBtn").hidden = true; return;
  }
  try {
    const token = await getIdTokenResult(user, true);
    if (token.claims.role !== "admin") {
      await signOut(auth);
      $("loginMessage").textContent = "هذا الحساب لا يحمل صلاحية الإدارة.";
      return;
    }
    $("loginPanel").hidden = true; $("dashboard").hidden = false; $("logoutBtn").hidden = false;
    await loadDashboard();
  } catch (error) { $("loginMessage").textContent = error.message; }
});

async function loadDashboard() {
  $("tripsList").textContent = "جارٍ تحميل الرحلات…";
  $("driversList").textContent = "جارٍ تحميل طلبات السائقين…";
  const [tripSnap, driverSnap] = await Promise.all([
    getDocs(query(collection(db, "trips"), orderBy("createdAt", "desc"), limit(100))),
    getDocs(query(collection(db, "driverApplications"), where("status", "==", "pending"), orderBy("createdAt", "desc"), limit(100)))
  ]);
  $("tripCount").textContent = String(tripSnap.size);
  $("driverCount").textContent = String(driverSnap.size);
  renderDrivers(driverSnap.docs.map(d => ({ id: d.id, ...d.data() })));
  renderTrips(tripSnap.docs.map(d => ({ id: d.id, ...d.data() })));
}

function addText(parent, tag, value, className = "") {
  const el = document.createElement(tag); el.textContent = value ?? "—"; if (className) el.className = className; parent.appendChild(el); return el;
}
function renderDrivers(items) {
  const root = $("driversList"); root.replaceChildren();
  if (!items.length) return addText(root, "p", "لا توجد طلبات اعتماد معلقة.", "empty");
  for (const item of items) {
    const box = document.createElement("div"); box.className = "item";
    addText(box, "h3", item.fullName || item.id);
    addText(box, "p", `الهاتف: ${item.phone || "—"}`);
    addText(box, "p", `المركبة: ${item.vehicleType || "—"} — ${item.vehicleModel || "—"}`);
    addText(box, "p", `معرّف المستخدم: ${item.id}`, "muted");
    const actions = document.createElement("div"); actions.className = "actions";
    const approve = document.createElement("button"); approve.textContent = "اعتماد السائق"; approve.addEventListener("click", () => reviewDriver(item.id, "approve"));
    const reject = document.createElement("button"); reject.textContent = "رفض الطلب"; reject.className = "danger"; reject.addEventListener("click", () => reviewDriver(item.id, "reject"));
    actions.append(approve, reject); box.appendChild(actions); root.appendChild(box);
  }
}
async function reviewDriver(uid, decision) {
  const label = decision === "approve" ? "اعتماد" : "رفض";
  if (!confirm(`هل تريد ${label} طلب السائق؟`)) return;
  try { await reviewDriverApplication({ uid, decision }); await loadDashboard(); }
  catch (error) { alert(error.message); }
}
function renderTrips(items) {
  const root = $("tripsList"); root.replaceChildren();
  if (!items.length) return addText(root, "p", "لا توجد حجوزات حتى الآن.", "empty");
  for (const trip of items) {
    const box = document.createElement("div"); box.className = "item";
    addText(box, "h3", `${trip.serviceType || "طلب خدمة"} — ${trip.status || "—"}`);
    addText(box, "p", `الانطلاق: ${trip.pickup || "—"}`);
    addText(box, "p", `الوجهة: ${trip.destination || "—"}`);
    addText(box, "p", `العميل: ${trip.customerId || "—"}`, "muted");
    addText(box, "p", `رقم الطلب: ${trip.id}`, "muted");
    const actions = document.createElement("div"); actions.className = "actions";
    const next = { accepted: "driver_arrived", driver_arrived: "in_progress", in_progress: "completed" }[trip.status];
    if (next) {
      const advance = document.createElement("button"); advance.textContent = `تحديث إلى ${next}`;
      advance.addEventListener("click", async () => { try { await updateTripStatus({ tripId: trip.id, status: next }); await loadDashboard(); } catch (error) { alert(error.message); } });
      actions.appendChild(advance);
    }
    if (!["completed", "cancelled"].includes(trip.status)) {
      const cancel = document.createElement("button"); cancel.textContent = "إلغاء الرحلة"; cancel.className = "danger";
      cancel.addEventListener("click", async () => { if (!confirm("تأكيد إلغاء الرحلة؟")) return; try { await cancelBooking({ tripId: trip.id }); await loadDashboard(); } catch (error) { alert(error.message); } });
      actions.appendChild(cancel);
    }
    if (actions.childElementCount) box.appendChild(actions);
    root.appendChild(box);
  }
}
