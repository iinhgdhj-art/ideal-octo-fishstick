// انسخ هذا الملف إلى firebase-config.js وأدخل إعدادات Web App من Firebase Console.
// هذه القيم العامة ليست Service Account ولا تمنح صلاحيات الإدارة وحدها.
export const firebaseConfig = {
  apiKey: "YOUR_WEB_API_KEY",
  authDomain: "king-travel-bf3ba.firebaseapp.com",
  projectId: "king-travel-bf3ba",
  appId: "YOUR_WEB_APP_ID"
};
export const appCheckSiteKey = "YOUR_RECAPTCHA_V3_SITE_KEY";
