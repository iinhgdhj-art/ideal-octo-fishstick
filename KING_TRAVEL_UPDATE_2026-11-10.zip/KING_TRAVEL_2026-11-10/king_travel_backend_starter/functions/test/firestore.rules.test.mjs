import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import test, { before, after, beforeEach } from "node:test";
import assert from "node:assert/strict";
import {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails
} from "@firebase/rules-unit-testing";
import { collection, doc, getDoc, getDocs, query, setDoc, where } from "firebase/firestore";

const here = path.dirname(fileURLToPath(import.meta.url));
const rules = await readFile(path.resolve(here, "../../firestore.rules"), "utf8");
const projectId = "demo-king-travel-rules";
let env;

before(async () => {
  env = await initializeTestEnvironment({
    projectId,
    firestore: { rules }
  });
});

after(async () => {
  await env?.cleanup();
});

beforeEach(async () => {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await setDoc(doc(db, "trips", "trip-customer-a"), {
      customerId: "customer-a",
      assignedDriverId: null,
      status: "requested"
    });
    await setDoc(doc(db, "trips", "trip-driver-b"), {
      customerId: "customer-a",
      assignedDriverId: "driver-b",
      status: "accepted"
    });
    await setDoc(doc(db, "users", "customer-a"), { role: "customer" });
    await setDoc(doc(db, "drivers", "driver-b"), {
      verificationStatus: "verified",
      isAvailable: false
    });
  });
});

test("unauthenticated users cannot read trips", async () => {
  const db = env.unauthenticatedContext().firestore();
  await assertFails(getDoc(doc(db, "trips", "trip-customer-a")));
});

test("customer can read own trip", async () => {
  const db = env.authenticatedContext("customer-a", { role: "customer" }).firestore();
  await assertSucceeds(getDoc(doc(db, "trips", "trip-customer-a")));
});

test("customer cannot read another customer's trip", async () => {
  const db = env.authenticatedContext("customer-z", { role: "customer" }).firestore();
  await assertFails(getDoc(doc(db, "trips", "trip-customer-a")));
});

test("approved driver can read an open requested trip", async () => {
  const db = env.authenticatedContext("driver-b", {
    role: "driver",
    driverApproved: true
  }).firestore();
  await assertSucceeds(getDoc(doc(db, "trips", "trip-customer-a")));
});

test("approved driver can read a trip assigned to them", async () => {
  const db = env.authenticatedContext("driver-b", {
    role: "driver",
    driverApproved: true
  }).firestore();
  await assertSucceeds(getDoc(doc(db, "trips", "trip-driver-b")));
});

test("driver cannot read a trip assigned to another driver", async () => {
  const db = env.authenticatedContext("driver-c", {
    role: "driver",
    driverApproved: true
  }).firestore();
  await assertFails(getDoc(doc(db, "trips", "trip-driver-b")));
});

test("unapproved driver cannot read open trips", async () => {
  const db = env.authenticatedContext("driver-pending", {
    role: "driver",
    driverApproved: false
  }).firestore();
  await assertFails(getDoc(doc(db, "trips", "trip-customer-a")));
});

test("client cannot write trips directly", async () => {
  const db = env.authenticatedContext("customer-a", { role: "customer" }).firestore();
  await assertFails(setDoc(doc(db, "trips", "forged-trip"), {
    customerId: "customer-a",
    status: "requested"
  }));
});

test("admin can read trips", async () => {
  const db = env.authenticatedContext("admin-1", { role: "admin" }).firestore();
  await assertSucceeds(getDoc(doc(db, "trips", "trip-customer-a")));
});


test("customer can list only own trips with a constrained query", async () => {
  const db = env.authenticatedContext("customer-a", { role: "customer" }).firestore();
  const ownTrips = query(collection(db, "trips"), where("customerId", "==", "customer-a"));
  const result = await assertSucceeds(getDocs(ownTrips));
  assert.equal(result.size, 2);
});

test("customer cannot list all trips without an ownership constraint", async () => {
  const db = env.authenticatedContext("customer-a", { role: "customer" }).firestore();
  await assertFails(getDocs(collection(db, "trips")));
});

test("approved driver can list open requests with a status constraint", async () => {
  const db = env.authenticatedContext("driver-b", { role: "driver", driverApproved: true }).firestore();
  const openTrips = query(collection(db, "trips"), where("status", "==", "requested"));
  const result = await assertSucceeds(getDocs(openTrips));
  assert.equal(result.size, 1);
});

test("approved driver can list trips assigned to them", async () => {
  const db = env.authenticatedContext("driver-b", { role: "driver", driverApproved: true }).firestore();
  const assignedTrips = query(collection(db, "trips"), where("assignedDriverId", "==", "driver-b"));
  const result = await assertSucceeds(getDocs(assignedTrips));
  assert.equal(result.size, 1);
});

test("driver cannot list all trips without a permitted query constraint", async () => {
  const db = env.authenticatedContext("driver-b", { role: "driver", driverApproved: true }).firestore();
  await assertFails(getDocs(collection(db, "trips")));
});

test("admin can list all trips", async () => {
  const db = env.authenticatedContext("admin-1", { role: "admin" }).firestore();
  const result = await assertSucceeds(getDocs(collection(db, "trips")));
  assert.equal(result.size, 2);
});
