import { initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore, FieldValue, Timestamp } from "firebase-admin/firestore";
import { HttpsError, onCall } from "firebase-functions/v2/https";

initializeApp();
const db = getFirestore();
const REGION = "europe-west1";

type Role = "customer" | "driver" | "admin";
function requireAuth(request: any) {
  if (!request.auth) throw new HttpsError("unauthenticated", "يجب تسجيل الدخول أولاً.");
  return request.auth;
}
function requireRole(auth: any, role: Role) {
  // Roles are exact by default: an admin must not inherit customer/driver actions.
  // Administrative overrides are handled explicitly in the functions that need them.
  if (auth.token.role !== role) {
    throw new HttpsError("permission-denied", "ليست لديك صلاحية تنفيذ هذا الإجراء.");
  }
}
function cleanText(value: unknown, field: string, max = 180): string {
  if (typeof value !== "string") throw new HttpsError("invalid-argument", `الحقل ${field} مطلوب.`);
  const v = value.trim();
  if (!v || v.length > max) throw new HttpsError("invalid-argument", `قيمة ${field} غير صالحة.`);
  return v;
}
const validServices = new Set([
  "فوري", "ليموزين بالساعة", "ليموزين باليوم", "رحلة سياحية", "بين المدن",
  "حجز فندق", "رحلة بحرية", "رحلة غوص", "رحلة صيد"
]);
const validCars = new Set([
  "سيدان فاخرة", "SUV فاخرة", "ليموزين VIP", "يخت فاخر خاص", "قارب مجهز", "غير مطلوب"
]);
const validNext: Record<string, string[]> = {
  accepted: ["driver_arrived"],
  driver_arrived: ["in_progress"],
  in_progress: ["completed"]
};

export const submitDriverApplication = onCall({ region: REGION, enforceAppCheck: true }, async (request) => {
  const auth = requireAuth(request);
  requireRole(auth, "customer");
  const data = request.data ?? {};
  const fullName = cleanText(data.fullName, "fullName", 100);
  const phone = cleanText(data.phone, "phone", 24);
  const vehicleType = cleanText(data.vehicleType, "vehicleType", 80);
  const vehicleModel = cleanText(data.vehicleModel, "vehicleModel", 100);
  const ref = db.collection("driverApplications").doc(auth.uid);
  const existing = await ref.get();
  if (existing.exists && ["pending", "approved"].includes(existing.data()?.status)) {
    throw new HttpsError("failed-precondition", "يوجد طلب اعتماد قائم أو حساب سائق معتمد بالفعل.");
  }
  await ref.set({
    uid: auth.uid, fullName, phone, vehicleType, vehicleModel,
    status: "pending",
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp()
  });
  return { status: "pending" };
});

export const reviewDriverApplication = onCall({ region: REGION, enforceAppCheck: true }, async (request) => {
  const auth = requireAuth(request);
  if (auth.token.role !== "admin") throw new HttpsError("permission-denied", "هذه العملية متاحة للإدارة فقط.");
  const uid = cleanText(request.data?.uid, "uid", 128);
  const decision = cleanText(request.data?.decision, "decision", 16);
  if (!["approve", "reject"].includes(decision)) {
    throw new HttpsError("invalid-argument", "قرار المراجعة غير صالح.");
  }
  const applicationRef = db.collection("driverApplications").doc(uid);
  const application = await db.runTransaction(async (tx) => {
    const snap = await tx.get(applicationRef);
    if (!snap.exists) throw new HttpsError("not-found", "طلب السائق غير موجود.");
    const data = snap.data()!;
    if (data.status !== "pending") throw new HttpsError("failed-precondition", "تمت مراجعة هذا الطلب مسبقًا.");
    tx.update(applicationRef, {
      status: "reviewing",
      reviewedBy: auth.uid,
      updatedAt: FieldValue.serverTimestamp()
    });
    return data;
  });

  let previousClaims: Record<string, unknown> = {};
  let claimsUpdated = false;
  try {
    const userRecord = await getAuth().getUser(uid);
    previousClaims = (userRecord.customClaims ?? {}) as Record<string, unknown>;
    const approved = decision === "approve";
    const nextClaims = {
      ...previousClaims,
      role: approved ? "driver" : "customer",
      driverApproved: approved
    };
    await getAuth().setCustomUserClaims(uid, nextClaims);
    claimsUpdated = true;

    const batch = db.batch();
    batch.update(applicationRef, {
      status: approved ? "approved" : "rejected",
      reviewedAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp()
    });
    batch.set(db.collection("drivers").doc(uid), approved ? {
      uid,
      fullName: application.fullName,
      phone: application.phone,
      vehicleType: application.vehicleType,
      vehicleModel: application.vehicleModel,
      verificationStatus: "verified",
      isAvailable: false,
      currentTripId: null,
      approvedAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp()
    } : {
      uid,
      verificationStatus: "rejected",
      isAvailable: false,
      currentTripId: null,
      updatedAt: FieldValue.serverTimestamp()
    }, { merge: true });
    await batch.commit();
    return { uid, status: approved ? "approved" : "rejected" };
  } catch (error) {
    if (claimsUpdated) {
      try { await getAuth().setCustomUserClaims(uid, previousClaims); } catch (_) { /* manual claim review may be needed */ }
    }
    try {
      await applicationRef.update({
        status: "pending",
        reviewedBy: FieldValue.delete(),
        updatedAt: FieldValue.serverTimestamp()
      });
    } catch (_) { /* leave the review state visible for admin recovery */ }
    throw error;
  }
});

export const createBooking = onCall({ region: REGION, enforceAppCheck: true }, async (request) => {
  const auth = requireAuth(request);
  requireRole(auth, "customer");
  const data = request.data ?? {};
  const pickup = cleanText(data.pickup, "pickup");
  const destination = cleanText(data.destination, "destination");
  const serviceType = cleanText(data.serviceType, "serviceType", 80);
  const vehicleType = cleanText(data.vehicleType, "vehicleType", 80);
  if (!validServices.has(serviceType)) throw new HttpsError("invalid-argument", "نوع الخدمة غير مدعوم.");
  if (!validCars.has(vehicleType)) throw new HttpsError("invalid-argument", "فئة المركبة غير مدعومة.");
  const passengers = Number(data.passengers);
  if (!Number.isInteger(passengers) || passengers < 1 || passengers > 8) {
    throw new HttpsError("invalid-argument", "عدد الركاب يجب أن يكون من 1 إلى 8.");
  }
  let scheduledAt: Timestamp | null = null;
  if (data.scheduledAt !== undefined && data.scheduledAt !== null && data.scheduledAt !== "") {
    const parsedDate = data.scheduledAt instanceof Date
      ? data.scheduledAt
      : new Date(data.scheduledAt);
    const scheduledMillis = parsedDate.getTime();
    if (!Number.isFinite(scheduledMillis) || scheduledMillis < Date.now() - 60000) {
      throw new HttpsError("invalid-argument", "موعد الحجز غير صالح أو في الماضي.");
    }
    scheduledAt = Timestamp.fromDate(parsedDate);
  }
  const ref = db.collection("trips").doc();
  await ref.create({
    customerId: auth.uid,
    pickup, destination, serviceType, vehicleType, passengers,
    scheduledAt,
    status: "requested",
    assignedDriverId: null,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp()
  });
  return { tripId: ref.id, status: "requested" };
});

export const setDriverAvailability = onCall({ region: REGION, enforceAppCheck: true }, async (request) => {
  const auth = requireAuth(request);
  requireRole(auth, "driver");
  if (auth.token.driverApproved !== true) throw new HttpsError("permission-denied", "حساب السائق غير معتمد.");
  const isAvailable = request.data?.isAvailable;
  if (typeof isAvailable !== "boolean") throw new HttpsError("invalid-argument", "قيمة التوفر غير صالحة.");
  const ref = db.collection("drivers").doc(auth.uid);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists || snap.data()?.verificationStatus !== "verified") {
      throw new HttpsError("permission-denied", "ملف السائق غير معتمد في قاعدة البيانات.");
    }
    const currentTripId = snap.data()?.currentTripId ?? null;
    if (isAvailable && currentTripId) {
      throw new HttpsError("failed-precondition", "لا يمكن التوفر أثناء وجود رحلة مسندة.");
    }
    tx.update(ref, { isAvailable, updatedAt: FieldValue.serverTimestamp() });
  });
  return { isAvailable };
});

export const claimTrip = onCall({ region: REGION, enforceAppCheck: true }, async (request) => {
  const auth = requireAuth(request);
  requireRole(auth, "driver");
  if (auth.token.driverApproved !== true) throw new HttpsError("permission-denied", "حساب السائق غير معتمد.");
  const tripId = cleanText(request.data?.tripId, "tripId", 128);
  const ref = db.collection("trips").doc(tripId);
  const driverRef = db.collection("drivers").doc(auth.uid);
  await db.runTransaction(async (tx) => {
    const tripSnap = await tx.get(ref);
    const driverSnap = await tx.get(driverRef);
    if (!tripSnap.exists) throw new HttpsError("not-found", "الحجز غير موجود.");
    if (!driverSnap.exists || driverSnap.data()?.verificationStatus !== "verified") {
      throw new HttpsError("permission-denied", "ملف السائق غير معتمد.");
    }
    const trip = tripSnap.data()!;
    const driver = driverSnap.data()!;
    if (driver.isAvailable !== true || driver.currentTripId) {
      throw new HttpsError("failed-precondition", "يجب أن يكون السائق متاحًا ولا توجد رحلة مسندة إليه.");
    }
    if (trip.status !== "requested" || trip.assignedDriverId !== null) {
      throw new HttpsError("failed-precondition", "تم استلام هذا الطلب بالفعل أو لم يعد متاحًا.");
    }
    tx.update(ref, {
      assignedDriverId: auth.uid,
      status: "accepted",
      acceptedAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp()
    });
    tx.update(driverRef, {
      isAvailable: false,
      currentTripId: tripId,
      updatedAt: FieldValue.serverTimestamp()
    });
  });
  return { tripId, status: "accepted" };
});

export const updateTripStatus = onCall({ region: REGION, enforceAppCheck: true }, async (request) => {
  const auth = requireAuth(request);
  const tripId = cleanText(request.data?.tripId, "tripId", 128);
  const nextStatus = cleanText(request.data?.status, "status", 40);
  if (!["driver_arrived", "in_progress", "completed"].includes(nextStatus)) {
    throw new HttpsError("invalid-argument", "حالة الرحلة المطلوبة غير صالحة.");
  }
  const ref = db.collection("trips").doc(tripId);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError("not-found", "الحجز غير موجود.");
    const trip = snap.data()!;
    const isAdmin = auth.token.role === "admin";
    if (!isAdmin && (auth.token.role !== "driver" || auth.token.driverApproved !== true || trip.assignedDriverId !== auth.uid)) {
      throw new HttpsError("permission-denied", "هذه الرحلة ليست مسندة إلى حسابك.");
    }
    if (!(validNext[trip.status] ?? []).includes(nextStatus)) {
      throw new HttpsError("failed-precondition", "انتقال حالة الرحلة غير مسموح.");
    }
    const driverRef = nextStatus === "completed" && trip.assignedDriverId
      ? db.collection("drivers").doc(trip.assignedDriverId)
      : null;
    const driverSnap = driverRef ? await tx.get(driverRef) : null;
    tx.update(ref, { status: nextStatus, updatedAt: FieldValue.serverTimestamp() });
    if (driverRef && driverSnap?.exists && driverSnap.data()?.currentTripId === tripId) {
      tx.update(driverRef, { isAvailable: true, currentTripId: null, updatedAt: FieldValue.serverTimestamp() });
    }
  });
  return { tripId, status: nextStatus };
});

export const cancelBooking = onCall({ region: REGION, enforceAppCheck: true }, async (request) => {
  const auth = requireAuth(request);
  const isAdmin = auth.token.role === "admin";
  if (!isAdmin) requireRole(auth, "customer");
  const tripId = cleanText(request.data?.tripId, "tripId", 128);
  const ref = db.collection("trips").doc(tripId);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError("not-found", "الحجز غير موجود.");
    const trip = snap.data()!;
    if (trip.status === "completed" || trip.status === "cancelled") {
      throw new HttpsError("failed-precondition", "لا يمكن إلغاء رحلة مكتملة أو ملغاة.");
    }
    if (!isAdmin && trip.customerId !== auth.uid) throw new HttpsError("permission-denied", "لا يمكنك إلغاء هذا الحجز.");
    if (trip.status !== "requested" && !isAdmin) {
      throw new HttpsError("failed-precondition", "بعد قبول السائق، يرجى التواصل مع الإدارة لإلغاء الرحلة.");
    }
    const driverRef = isAdmin && trip.assignedDriverId
      ? db.collection("drivers").doc(trip.assignedDriverId)
      : null;
    const driverSnap = driverRef ? await tx.get(driverRef) : null;
    tx.update(ref, {
      status: "cancelled",
      cancelledAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
      cancelledBy: auth.uid
    });
    if (driverRef && driverSnap?.exists && driverSnap.data()?.currentTripId === tripId) {
      tx.update(driverRef, { isAvailable: true, currentTripId: null, updatedAt: FieldValue.serverTimestamp() });
    }
  });
  return { tripId, status: "cancelled" };
});
