const { initializeApp, applicationDefault } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");

async function main() {
  const uid = process.argv[2];
  if (!uid) throw new Error("Usage: node scripts/set-admin.cjs FIREBASE_AUTH_UID");
  initializeApp({ credential: applicationDefault() });
  const auth = getAuth();
  const user = await auth.getUser(uid);
  await auth.setCustomUserClaims(uid, { ...(user.customClaims || {}), role: "admin", driverApproved: false });
  process.stdout.write(`Admin role assigned to ${uid}. Force a fresh ID token by signing out and in.\n`);
}
main().catch(error => { process.stderr.write(`${error.message}\n`); process.exit(1); });
