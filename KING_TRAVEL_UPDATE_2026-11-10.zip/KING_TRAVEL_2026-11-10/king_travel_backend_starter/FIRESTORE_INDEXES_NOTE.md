# فهارس Firestore المقترحة
قد يطلب Firestore إنشاء فهرس مركب عند تشغيل استعلامات قائمة الطلبات.
- `trips`: status ASC + createdAt DESC (طلبات السائق المفتوحة).
- `trips`: customerId ASC + createdAt DESC (رحلات العميل).
- `trips`: assignedDriverId ASC + createdAt DESC (رحلات السائق).
أنشئ الفهارس من رابط الخطأ الذي يعرضه Firestore أو أضفها إلى firestore.indexes.json بعد تثبيت الاستعلامات النهائية.
