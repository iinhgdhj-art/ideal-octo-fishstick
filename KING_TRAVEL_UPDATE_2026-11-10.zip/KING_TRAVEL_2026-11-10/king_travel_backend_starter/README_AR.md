# KING TRAVEL — Backend Starter آمن ومشترك

هذه حزمة تأسيسية قابلة للدمج مع مشروع Firebase، وليست نشرًا تلقائيًا. لا تحتوي على مفاتيح أو بيانات اعتماد. لا تنفذ أوامر النشر على الإنتاج قبل مراجعة القواعد والوظائف واختبار Emulator.

## البنية
- Firebase Authentication لتسجيل الدخول برقم الهاتف.
- Cloud Functions (Callable) لإنشاء الحجوزات وقبولها وتحديث حالتها وإلغائها.
- Runtime المعتمد لوظائف الخادم: Node.js 22؛ تم تحديث `functions/package.json` لهذا الإصدار لأن Node.js 20 وصل إلى تاريخ الإيقاف في 30 أكتوبر 2026.
- Cloud Firestore لتخزين الرحلات المشتركة.
- أدوار موثوقة عبر Custom Claims: `role=customer|driver|admin`، وللسائق `driverApproved=true`.
- العميل والسائق والإدارة يقرؤون البيانات المسموح بها، لكن لا يكتب أي تطبيق مباشرة في مستندات الرحلات.

## دورة الحجز
`requested → accepted → driver_arrived → in_progress → completed`
ويمكن إلغاء الطلب قبل بدء الرحلة وفق السياسة المحددة في الدالة.

## قبل التشغيل
1. أنشئ نسخة احتياطية من قواعد Firestore الحالية.
2. تم ضبط ملف `.firebaserc` في هذه النسخة على المشروع الذي أكدته: `king-travel-bf3ba`. تحقق من الاختيار بالأمر `firebase use` قبل أي نشر.
3. ثبّت Firebase CLI ثم سجّل الدخول:
   `npm install -g firebase-tools`
   `firebase login`
4. من مجلد الحزمة تحقق من المشروع النشط: `firebase use`، ويجب أن يظهر `king-travel-bf3ba` قبل أي أمر نشر.
5. انسخ `admin/firebase-config.example.js` إلى `admin/firebase-config.js` وأدخل إعدادات Web App ومفتاح reCAPTCHA v3 لـ App Check من Firebase Console. أضف نطاق Firebase Hosting إلى Authorized Domains في Authentication.
6. ثبّت اعتماديات الوظائف:
   `cd functions && npm install && cd ..`
7. فعّل Phone Authentication وFirestore وApp Check من Firebase Console. يحتاج نشر Cloud Functions إلى خطة Blaze؛ راجع التكلفة قبل التفعيل.
8. جهّز تطبيقات Android/iOS/Web لتفعيل Firebase App Check قبل فرضه في الإنتاج.
9. أنشئ أول مستخدم إدارة عبر Phone Auth، ثم شغّل `node functions/scripts/set-admin.cjs FIREBASE_AUTH_UID` من بيئة موثوقة بعد إعداد Application Default Credentials. لا تضع Service Account في تطبيق العميل أو السائق.
10. اختبر في Emulator قبل النشر:
   `firebase emulators:start --only auth,firestore,functions`
11. بعد نجاح الاختبارات ومراجعة المشروع، انشر القواعد والفهارس والوظائف:
   `firebase deploy --only firestore:rules,firestore:indexes,functions`
12. بعد إنشاء `admin/firebase-config.js` واختبار لوحة الإدارة على بيئة staging، انشر الاستضافة:
   `firebase deploy --only hosting`

## تعيين الأدوار
استخدم سكربتًا إداريًا آمنًا يعمل محليًا في بيئة موثوقة، أو Cloud Function إدارية محمية. لا تسمح للمستخدم بتعديل دوره بنفسه. مثال من بيئة Node إدارية بعد إعداد Application Default Credentials:

```js
const admin = require("firebase-admin");
admin.initializeApp();
async function setRole(uid, role, driverApproved = false) {
  await admin.auth().setCustomUserClaims(uid, {
    role,
    ...(role === "driver" ? { driverApproved } : {})
  });
}
```

شغّل هذا المثال من جهاز/بيئة إدارية موثوقة فقط، ولا ترفع مفاتيح الخدمة إلى Git أو الويب.

## ملاحظات يجب حسمها قبل التشغيل التجاري
- الأسعار: الدوال لا تثق بسعر يرسله العميل. أضف جدول أسعار معتمدًا في Firestore يقرأه الخادم فقط أو آلية عروض أسعار إدارية.
- الإلغاء بعد قبول السائق: السياسة الحالية تسمح للعميل بالإلغاء فقط قبل قبول السائق؛ عدّلها إذا أردت رسوم إلغاء.
- المدفوعات: غير مفعّلة في هذه الحزمة.
- الخرائط وGPS والإشعارات: نقاط تكامل لاحقة وليست مفعّلة هنا.
- أُضيفت لوحة إدارة ويب تأسيسية داخل `admin/` لمراجعة الطلبات والحجوزات بعد تسجيل الدخول بحساب يحمل Custom Claim `role=admin`.
- أُضيف مسار تقديم طلب اعتماد سائق ومراجعته إداريًا؛ لا يوجد رفع وثائق هوية أو فحص قانوني للسائق في هذه النسخة.
- الحماية من إساءة الاستخدام: فعّل App Check، وحدود الطلبات، ومراقبة السجلات قبل الإطلاق.

## متغيرات ومناطق
الدوال تستخدم `europe-west1` افتراضيًا. يمكن تغيير المنطقة بما يتوافق مع مشروعك ومتطلبات زمن الاستجابة/توفر Firebase.
