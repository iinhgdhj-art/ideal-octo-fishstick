# ربط واجهة العميل والسائق بالـ Backend

> أمثلة دمج فقط. لا تستبدل ملفات الموقع الحي قبل أخذ نسخة احتياطية وتجربة بيئة staging.

## إعداد Firebase Web SDK
ثبّت SDK في مشروع الواجهة:
```bash
npm install firebase
```

أنشئ `src/firebase.js` باستخدام إعدادات Web App العامة من Firebase Console (ليست Service Account):
```js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { initializeAppCheck, ReCaptchaV3Provider } from "firebase/app-check";
import { getFunctions, httpsCallable } from "firebase/functions";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "WEB_APP_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "YOUR_WEB_APP_ID"
};

const app = initializeApp(firebaseConfig);
// فعّل App Check بعد تسجيل موقعك والحصول على reCAPTCHA v3 site key.
initializeAppCheck(app, {
  provider: new ReCaptchaV3Provider("RECAPTCHA_V3_SITE_KEY"),
  isTokenAutoRefreshEnabled: true
});

export const auth = getAuth(app);
export const db = getFirestore(app);
export const functions = getFunctions(app, "europe-west1");
export const createBooking = httpsCallable(functions, "createBooking");
export const claimTrip = httpsCallable(functions, "claimTrip");
export const setDriverAvailability = httpsCallable(functions, "setDriverAvailability");
export const updateTripStatus = httpsCallable(functions, "updateTripStatus");
export const cancelBooking = httpsCallable(functions, "cancelBooking");
```

## من زر تأكيد الحجز في واجهة العميل
يجب تسجيل دخول العميل أولًا (Firebase Phone Auth)، ثم استدعاء الدالة:
```js
import { createBooking } from "./firebase.js";

async function submitRealBooking(form) {
  const result = await createBooking({
    pickup: form.pickup,
    destination: form.destination,
    serviceType: form.serviceType,
    vehicleType: form.vehicleType,
    passengers: Number(form.passengers),
    scheduledAt: form.scheduledAt || null
  });
  // اعرض رقم الحجز والحالة returned by server.
  return result.data;
}
```
لا تكتب إلى `trips` مباشرة ولا تعتمد على سعر محسوب في المتصفح.

## عرض حجوزات العميل
```js
import { collection, onSnapshot, query, where, orderBy } from "firebase/firestore";
import { auth, db } from "./firebase.js";

const q = query(
  collection(db, "trips"),
  where("customerId", "==", auth.currentUser.uid),
  orderBy("createdAt", "desc")
);
const unsubscribe = onSnapshot(q, snapshot => {
  const trips = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
  renderTrips(trips);
});
```

## شاشة الطلبات المفتوحة في تطبيق السائق
```js
import { collection, onSnapshot, query, where, orderBy } from "firebase/firestore";
import { auth, db, claimTrip } from "./firebase.js";

const q = query(
  collection(db, "trips"),
  where("status", "==", "requested"),
  orderBy("createdAt", "desc")
);
const unsubscribe = onSnapshot(q, snapshot => {
  renderOpenTrips(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
});

async function setAvailable(isAvailable) {
  return (await setDriverAvailability({ isAvailable })).data;
}

async function acceptTrip(tripId) {
  // الخادم يتحقق من اعتماد السائق وتوفره ويحسم التنافس ذريًا.
  return (await claimTrip({ tripId })).data;
}
```

للتحديث بعد قبول الطلب، يستدعي تطبيق السائق `updateTripStatus({tripId, status:"driver_arrived"})` ثم `in_progress` ثم `completed`.

## تنبيهات
- لا تعرض شاشة الطلبات المفتوحة قبل التحقق من أن المستخدم سائق معتمد.
- اقرأ الرحلات من استعلامات مقيّدة بـ `customerId` أو `status` كما في الأمثلة؛ قواعد Firestore ليست مرشحًا للنتائج.
- لا تضع Service Account أو Admin SDK في المتصفح أو تطبيق الهاتف.
- يجب إعداد Phone Auth وApp Check لكل منصة واختبارهما في مشروع تجريبي أولًا.
- لا تزال الأسعار والمدفوعات والإشعارات وGPS ولوحة الإدارة خارج نطاق هذه الحزمة.
