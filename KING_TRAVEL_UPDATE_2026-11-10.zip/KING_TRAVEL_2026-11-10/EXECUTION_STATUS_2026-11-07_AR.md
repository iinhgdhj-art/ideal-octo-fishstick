# تقرير تنفيذ KING TRAVEL — 7 نوفمبر 2026

## تعديلات مصدر أُضيفت في هذه النسخة
0. تم تحديث `functions/package.json` من Node.js 20 إلى Node.js 22؛ إذ إن Runtime Node.js 20 وصل إلى تاريخ الإيقاف الرسمي 30 أكتوبر 2026، بينما Node.js 22 ما زال مدعومًا.
1. أضيفت موارد أيقونة Android: أيقونة تكيفية لإصدارات Android 8.0+ وموارد Vector احتياطية للأجهزة الأقدم.
2. تم ربط `android:icon` و`android:roundIcon` في `AndroidManifest.xml`.
3. أصبح `submitDriverApplication` يتطلب دور `customer` صراحةً.
4. أصبح `cancelBooking` يتطلب دور `customer` أو `admin` صراحةً، ولا يكفي تسجيل الدخول وحده.
5. توسعت اختبارات Firestore لتغطي استعلامات القوائم المقيدة للعميل والسائق والإدارة، بالإضافة إلى منع القوائم غير المقيدة.
6. أضيفت حالات تحقق الأيقونة والاستعلامات إلى قائمة QA.

## فحوص ساكنة تمت
- فحص JavaScript وملف الاختبار باستخدام `node --check`.
- تحليل ملفات JSON.
- التحقق من وجود ملفات موارد الأيقونة وربطها في Manifest.
- مراجعة شروط الأدوار في وظائف تقديم طلب السائق وإلغاء الحجز.

## ما لم يتم اختباره
- لا يوجد Gradle أو Android SDK أو Firebase CLI في بيئة التنفيذ.
- لم يتم بناء Android أو تثبيت التطبيق، لذا لم يتم التحقق بصريًا من الأيقونة على جهاز.
- لم يتم تثبيت اعتماديات Firebase أو بناء TypeScript.
- لم يتم تشغيل اختبارات Firestore Emulator أو Callable Functions.
- لم يتم نشر أي شيء على Firebase `king-travel-bf3ba` أو Google Play.

## البيئة المتاحة
- Java 21.0.12
- Node.js 22.16.0
- npm 10.9.2
- TypeScript compiler 5.8.3 (عام)

## متطلبات Google Play التي تمت مراجعتها اليوم
- API 36 مطلوب للتطبيقات الجديدة منذ 31 أغسطس 2026.
- حساب Play Console: 18 عامًا أو أكثر، ورسم تسجيل لمرة واحدة 25 دولارًا، والتحقق من الهوية ووسائل الاتصال.
- الحساب الشخصي الجديد يتطلب التحقق من جهاز Android فعلي عبر Play Console app، إضافة إلى 12 مختبرًا لمدة 14 يومًا للاختبار المغلق.
- سياسة Google Play الحالية المنشورة بتاريخ 29 أكتوبر 2026 تتطلب سياسة خصوصية عامة داخل التطبيق وعلى Play Console، وإفصاح Data Safety مطابقًا لسلوك التطبيق.

## الخطوة التالية
على كمبيوتر متصل بالإنترنت، تثبيت Android Studio وSDK Platform 36 وGradle/Firebase CLI، ثم إنشاء Gradle Wrapper وتشغيل اختبارات Android وFirebase Emulator على مشروع تجريبي `demo-king-travel` فقط. لا تنفذ deploy للإنتاج قبل نجاح الاختبارات ومراجعة إعداد App Check وبيانات Firebase.
