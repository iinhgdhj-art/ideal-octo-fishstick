package com.kingtravel.app

import org.junit.Assert.assertEquals
import org.junit.Test
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class BookingScheduleTest {
    @Test
    fun scheduleIncludesExplicitTimezoneOffsetAndReadableDisplay() {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("Africa/Cairo"), Locale.US).apply {
            clear()
            set(2026, Calendar.NOVEMBER, 10, 9, 30, 0)
        }

        val result = formatBookingSchedule(calendar, Locale.US)

        assertEquals("2026-11-10T09:30:00+02:00", result.iso8601)
        assertEquals("10/11/2026 09:30", result.display)
    }
}
