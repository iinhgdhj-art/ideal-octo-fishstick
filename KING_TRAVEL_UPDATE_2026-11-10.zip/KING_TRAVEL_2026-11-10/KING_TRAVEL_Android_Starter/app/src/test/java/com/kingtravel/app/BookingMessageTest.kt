package com.kingtravel.app

import org.junit.Assert.assertTrue
import org.junit.Test

class BookingMessageTest {
    @Test
    fun messageContainsCatalogAndTripDetails() {
        val message = buildBookingMessage(
            category = "الرحلات البحرية",
            serviceType = "رحلة بحرية",
            vehicleType = "يخت فاخر خاص",
            pickup = "مرسى علم",
            destination = "رحلة صيد خاصة",
            dateTime = "غدًا 8 صباحًا",
            passengers = "4"
        )
        assertTrue(message.contains("القسم: الرحلات البحرية"))
        assertTrue(message.contains("نوع الطلب: رحلة بحرية"))
        assertTrue(message.contains("فئة المركبة/القارب: يخت فاخر خاص"))
        assertTrue(message.contains("مكان الانطلاق: مرسى علم"))
        assertTrue(message.contains("الوجهة/التفاصيل: رحلة صيد خاصة"))
        assertTrue(message.contains("الموعد: غدًا 8 صباحًا"))
        assertTrue(message.contains("عدد الركاب: 4"))
    }

    @Test
    fun blankDateIsMarkedAsUnspecified() {
        val message = buildBookingMessage("الغوص", "رحلة غوص", "قارب مجهز", "الفندق", "مركز الغوص", "", "2")
        assertTrue(message.contains("الموعد: غير محدد"))
    }
    @Test
    fun messageIncludesOffsetAwareScheduleWhenSelected() {
        val message = buildBookingMessage(
            category = "الانتقالات والسيارات",
            serviceType = "ليموزين بالساعة",
            vehicleType = "سيدان فاخرة",
            pickup = "المطار",
            destination = "الفندق",
            dateTime = "10/11/2026 09:30",
            passengers = "2",
            scheduledAtIso = "2026-11-10T09:30:00+02:00"
        )
        assertTrue(message.contains("الموعد: 10/11/2026 09:30"))
        assertTrue(message.contains("موعد الحجز المعياري (ISO 8601): 2026-11-10T09:30:00+02:00"))
    }

}
