package com.kingtravel.app

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Waves
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar
import java.util.TimeZone

private val Navy = Color(0xFF071A2B)
private val Gold = Color(0xFFD8B15A)
private val Cream = Color(0xFFF7F4ED)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                KingTravelApp()
            }
        }
    }
}

@Composable
fun KingTravelApp() {
    val context = LocalContext.current
    var selectedService by remember { mutableStateOf("الانتقالات والسيارات") }
    var serviceType by remember { mutableStateOf("فوري") }
    var vehicleType by remember { mutableStateOf("سيدان فاخرة") }
    var pickup by remember { mutableStateOf("") }
    var destination by remember { mutableStateOf("") }
    var dateTimeDisplay by remember { mutableStateOf("") }
    var scheduledAtIso by remember { mutableStateOf("") }
    var passengers by remember { mutableStateOf("1") }
    var privacyOpen by remember { mutableStateOf(false) }

    // Use a real date/time picker so a later Firebase integration can send a
    // timezone-aware ISO-8601 value instead of free-form text such as "tomorrow".
    val chooseSchedule = {
        // KING TRAVEL's current service area is Marsa Alam, so booking times
        // must use Egypt's zone even when a tourist's phone is set to Czech time.
        val serviceTimeZone = TimeZone.getTimeZone("Africa/Cairo")
        val now = Calendar.getInstance(serviceTimeZone)
        val today = Calendar.getInstance(serviceTimeZone).apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selected = Calendar.getInstance(serviceTimeZone).apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, dayOfMonth)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                TimePickerDialog(
                    context,
                    { _, hourOfDay, minute ->
                        selected.set(Calendar.HOUR_OF_DAY, hourOfDay)
                        selected.set(Calendar.MINUTE, minute)
                        if (selected.timeInMillis <= System.currentTimeMillis()) {
                            dateTimeDisplay = ""
                            scheduledAtIso = ""
                            Toast.makeText(context, "اختر موعدًا في المستقبل", Toast.LENGTH_SHORT).show()
                        } else {
                            val formatted = formatBookingSchedule(selected)
                            dateTimeDisplay = formatted.display
                            scheduledAtIso = formatted.iso8601
                        }
                    },
                    now.get(Calendar.HOUR_OF_DAY),
                    now.get(Calendar.MINUTE),
                    true
                ).show()
            },
            now.get(Calendar.YEAR),
            now.get(Calendar.MONTH),
            now.get(Calendar.DAY_OF_MONTH)
        ).apply {
            datePicker.minDate = today.timeInMillis
        }.show()
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy,
            secondary = Gold,
            background = Cream,
            surface = Color.White
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .background(Cream)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(12.dp))
            Text("KING", color = Navy, fontSize = 38.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
            Text("TRAVEL", color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = 7.sp)
            Spacer(Modifier.height(10.dp))
            Text(
                "اكتشف رحلتك القادمة",
                color = Navy,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                "خدمات سياحية وانتقالات ورحلات بحرية في مكان واحد",
                color = Color.DarkGray,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
            )

            Text("اختر الخدمة", color = Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            ServiceCard(Icons.Filled.DirectionsCar, "الانتقالات والسيارات", "انتقالات المطار والجولات الخاصة", selectedService == "الانتقالات والسيارات") { selectedService = "الانتقالات والسيارات"; serviceType = "فوري"; vehicleType = "سيدان فاخرة" }
            ServiceCard(Icons.Filled.Flight, "رحلات وسياحة", "استفسر عن البرامج والرحلات السياحية", selectedService == "رحلات وسياحة") { selectedService = "رحلات وسياحة"; serviceType = "رحلة سياحية"; vehicleType = "سيدان فاخرة" }
            ServiceCard(Icons.Filled.Hotel, "الفنادق والإقامة", "اطلب المساعدة في خيارات الإقامة", selectedService == "الفنادق والإقامة") { selectedService = "الفنادق والإقامة"; serviceType = "حجز فندق"; vehicleType = "غير مطلوب" }
            ServiceCard(Icons.Filled.DirectionsBoat, "الرحلات البحرية", "رحلات بالقارب وتجارب البحر", selectedService == "الرحلات البحرية") { selectedService = "الرحلات البحرية"; serviceType = "رحلة بحرية"; vehicleType = "يخت فاخر خاص" }
            ServiceCard(Icons.Filled.Waves, "الغوص والسنوركل", "استفسر عن تجارب الغوص والأنشطة البحرية", selectedService == "الغوص والسنوركل") { selectedService = "الغوص والسنوركل"; serviceType = "رحلة غوص"; vehicleType = "قارب مجهز" }
            ServiceCard(Icons.Filled.Explore, "رحلات الصيد", "رحلات صيد من قارب مجهز", selectedService == "رحلات الصيد") { selectedService = "رحلات الصيد"; serviceType = "رحلة صيد"; vehicleType = "قارب مجهز" }

            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("تفاصيل الخدمة", color = Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    SelectorField(
                        label = "نوع الطلب",
                        selected = serviceType,
                        options = listOf("فوري", "ليموزين بالساعة", "ليموزين باليوم", "رحلة سياحية", "بين المدن", "حجز فندق", "رحلة بحرية", "رحلة غوص", "رحلة صيد")
                    ) { serviceType = it }
                    SelectorField(
                        label = "فئة المركبة أو القارب",
                        selected = vehicleType,
                        options = listOf("سيدان فاخرة", "SUV فاخرة", "ليموزين VIP", "يخت فاخر خاص", "قارب مجهز", "غير مطلوب")
                    ) { vehicleType = it }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("طلب خدمة مبدئي", color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("الخدمة المختارة: $selectedService", color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp, bottom = 12.dp))
                    OutlinedTextField(
                        value = pickup,
                        onValueChange = { pickup = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("مكان الانطلاق") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = destination,
                        onValueChange = { destination = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("الوجهة أو تفاصيل الخدمة") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { chooseSchedule() },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)
                    ) {
                        Text(if (dateTimeDisplay.isBlank()) "اختيار موعد الرحلة (توقيت مصر)" else "الموعد: $dateTimeDisplay (توقيت مصر)")
                    }
                    if (dateTimeDisplay.isNotBlank()) {
                        TextButton(
                            onClick = {
                                dateTimeDisplay = ""
                                scheduledAtIso = ""
                            },
                            modifier = Modifier.align(Alignment.End)
                        ) { Text("مسح الموعد") }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = passengers,
                        onValueChange = { passengers = it.filter(Char::isDigit).take(1) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("عدد الركاب (1–8)") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("إرسال الطلب عبر واتساب — مصر", color = Navy, fontWeight = FontWeight.Bold)
                    Button(
                        onClick = {
                            val message = buildBookingMessage(selectedService, serviceType, vehicleType, pickup, destination, dateTimeDisplay, passengers, scheduledAtIso)
                            openWhatsApp(context, "201142480373", message)
                        },
                        enabled = pickup.isNotBlank() && destination.isNotBlank() && (passengers.toIntOrNull()?.let { it in 1..8 } == true),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Navy)
                    ) { Text("إرسال إلى الرقم المصري", color = Color.White) }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = {
                            val message = buildBookingMessage(selectedService, serviceType, vehicleType, pickup, destination, dateTimeDisplay, passengers, scheduledAtIso)
                            openWhatsApp(context, "420728479545", message)
                        },
                        enabled = pickup.isNotBlank() && destination.isNotBlank() && (passengers.toIntOrNull()?.let { it in 1..8 } == true),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)
                    ) { Text("إرسال إلى الرقم التشيكي") }
                    Text(
                        "هذا طلب مبدئي يفتح واتساب لإرساله يدويًا. لا يُعد الحجز مؤكدًا ولا يُحفظ في قاعدة بيانات KING TRAVEL بعد.",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Text("تواصل معنا للحجز والاستفسار", color = Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            ContactButton("اتصال — مصر", Icons.Filled.Call) {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:+201142480373"))
                context.startActivity(intent)
            }
            ContactButton("واتساب — مصر", Icons.Filled.Chat) {
                openWhatsApp(context, "201142480373")
            }
            ContactButton("Call — Czech Republic", Icons.Filled.Call) {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:+420728479545"))
                context.startActivity(intent)
            }
            ContactButton("WhatsApp — Czech Republic", Icons.Filled.Chat) {
                openWhatsApp(context, "420728479545")
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "KING TRAVEL • خدمة العملاء",
                color = Color.Gray,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
            TextButton(onClick = { privacyOpen = true }) {
                Text("سياسة الخصوصية", color = Navy)
            }
            Spacer(Modifier.height(8.dp))
        }
        if (privacyOpen) {
            PrivacyPolicyDialog(onDismiss = { privacyOpen = false })
        }
    }
}

@Composable
private fun PrivacyPolicyDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("سياسة خصوصية KING TRAVEL") },
        text = {
            Column(
                modifier = Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("هذه المعلومات تخص النسخة الحالية من التطبيق، التي تقدم طلبات مبدئية عبر تطبيق واتساب الخارجي.")
                Text("البيانات التي تدخلها: قد تكتب مكان الانطلاق والوجهة وموعد الرحلة وعدد الركاب، وتختار نوع الخدمة وفئة المركبة أو القارب. تبقى هذه القيم داخل شاشة التطبيق مؤقتًا أثناء الاستخدام، ولا تُحفظ في قاعدة بيانات KING TRAVEL في هذه النسخة.")
                Text("عند اختيار إرسال الطلب، يفتح التطبيق واتساب برسالة جاهزة إلى الرقم الذي اخترته. لا تُرسل الرسالة تلقائيًا؛ يمكنك مراجعتها ثم إرسالها بنفسك. بعد الانتقال إلى واتساب، تخضع البيانات التي ترسلها لسياسة وشروط واتساب.")
                Text("أزرار الاتصال تفتح تطبيق الهاتف برقم KING TRAVEL، ولا تجري المكالمة دون تأكيدك.")
                Text("لا تتضمن هذه النسخة تسجيل حساب، أو جمع موقع GPS، أو تتبعًا في الخلفية، أو تكامل Firebase، أو أدوات إعلانات وتحليلات بحسب ملفات المصدر الحالية.")
                Text("لا يحتفظ التطبيق بسجل طلبات أو حسابات يمكن حذفها في هذه النسخة. إذا أضيفت الحجوزات المركزية أو الحسابات أو الموقع مستقبلًا، فسيتم تحديث سياسة الخصوصية وإتاحة آليات الحذف والإفصاح المناسبة قبل إطلاق تلك الوظائف.")
                Text("للاستفسارات المتعلقة بالخصوصية، تواصل مع KING TRAVEL عبر الهاتف أو واتساب:")
                Text("مصر: +201142480373\nالتشيك: +420728479545", color = Gold, fontWeight = FontWeight.Bold)
                Text("آخر تحديث: 2 نوفمبر 2026", color = Color.Gray, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

@Composable
private fun ServiceCard(icon: ImageVector, title: String, description: String, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFFFF7E5) else Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(48.dp).background(Navy, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Gold, modifier = Modifier.size(27.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(4.dp))
                Text(description, color = Color.DarkGray, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun SelectorField(label: String, selected: String, options: List<String>, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text(label, color = Navy, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Box(Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selected, color = Navy)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = { onSelected(option); expanded = false }
                    )
                }
            }
        }
    }
}

@Composable
private fun ContactButton(label: String, icon: ImageVector, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).heightIn(min = 48.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Navy)
    ) {
        Icon(icon, contentDescription = null, tint = Gold)
        Spacer(Modifier.width(9.dp))
        Text(label, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}


private fun openWhatsApp(context: android.content.Context, number: String, message: String? = null) {
    val query = message?.let { "?text=${Uri.encode(it)}" } ?: ""
    val appUri = Uri.parse("https://wa.me/$number$query")
    val intent = Intent(Intent.ACTION_VIEW, appUri)
    context.startActivity(intent)
}
