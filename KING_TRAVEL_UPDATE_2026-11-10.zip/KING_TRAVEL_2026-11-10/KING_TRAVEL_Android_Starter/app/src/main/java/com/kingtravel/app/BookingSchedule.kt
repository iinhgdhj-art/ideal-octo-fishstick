package com.kingtravel.app

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** A display value for people and an offset-aware value for future backend calls. */
internal data class BookingScheduleValue(
    val iso8601: String,
    val display: String
)

internal fun formatBookingSchedule(
    calendar: Calendar,
    locale: Locale = Locale.getDefault()
): BookingScheduleValue {
    val selected = calendar.clone() as Calendar
    val isoFormatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).apply {
        timeZone = selected.timeZone
    }
    val displayFormatter = SimpleDateFormat("dd/MM/yyyy HH:mm", locale).apply {
        timeZone = selected.timeZone
    }
    return BookingScheduleValue(
        iso8601 = isoFormatter.format(selected.time),
        display = displayFormatter.format(selected.time)
    )
}
