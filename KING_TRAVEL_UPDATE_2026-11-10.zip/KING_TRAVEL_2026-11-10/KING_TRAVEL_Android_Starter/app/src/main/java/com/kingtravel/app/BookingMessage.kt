package com.kingtravel.app

internal fun buildBookingMessage(
    category: String,
    serviceType: String,
    vehicleType: String,
    pickup: String,
    destination: String,
    dateTime: String,
    passengers: String,
    scheduledAtIso: String = ""
): String = "طلب خدمة من تطبيق KING TRAVEL\n" +
    "القسم: $category\n" +
    "نوع الطلب: $serviceType\n" +
    "فئة المركبة/القارب: $vehicleType\n" +
    "مكان الانطلاق: $pickup\n" +
    "الوجهة/التفاصيل: $destination\n" +
    "الموعد: ${dateTime.ifBlank { "غير محدد" }}\n" +
    "عدد الركاب: $passengers\n" +
    (if (scheduledAtIso.isBlank()) "" else "موعد الحجز المعياري (ISO 8601): $scheduledAtIso\n") +
    "أرجو تأكيد التوفر والسعر النهائي."
