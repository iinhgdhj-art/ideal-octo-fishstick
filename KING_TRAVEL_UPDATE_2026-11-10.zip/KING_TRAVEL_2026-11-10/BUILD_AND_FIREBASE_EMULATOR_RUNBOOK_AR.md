# KING TRAVEL — تجهيز البناء واختبارات Firebase المحلية

## تحديث 7 نوفمبر 2026: Runtime وظائف Firebase
- كان `functions/package.json` يحدد Node.js 20، لكن جدول Google Cloud الرسمي يحدد 30 أكتوبر 2026 موعد إيقاف Runtime Node.js 20.
- تم تحديث `engines.node` إلى `22` في هذه الحزمة. جدول الدعم الرسمي يحدد Node.js 22 كـ Runtime مدعوم، مع موعد إيقاف مجدول 31 أكتوبر 2027.
- يجب استخدام Node.js 22 محليًا عند بناء وظائف Firebase واختبارها.

## نتيجة فحص بيئة التنفيذ الحالية (7 نوفمبر 2026)
- Java موجود: OpenJDK 21.0.12.
- Node.js موجود: v22.16.0، وهو متوافق مع Runtime المحدد في `functions/package.json`.
- Gradle غير موجود.
- Android SDK / sdkmanager / adb غير موجودة.
- Firebase CLI غير موجود.
- Docker غير موجود.
- لا يوجد Gradle Wrapper JAR في ملفات المشروع أو ذاكرة البيئة.
- اتصال DNS الخارجي غير متاح في بيئة التنفيذ الحالية؛ تعذر تنزيل Gradle وAndroid SDK وFirebase CLI وحزم npm ومحاكي Firebase.

لذلك **لم يتم إنشاء Gradle Wrapper مكتمل، ولم يتم بناء APK، ولم يتم تشغيل Firebase Emulator**. لم يُنشر أي شيء إلى مشروع Firebase الفعلي.

## إنشاء Gradle Wrapper على جهاز التطوير
المتطلبات:
- Android Studio حديث مع Android SDK Platform 36 وBuild Tools المناسبة.
- JDK 17.
- Gradle 8.11.1 مثبت مؤقتًا على PATH (أو تثبيته من بيئة Android Studio).

من داخل مجلد `KING_TRAVEL_Android_Starter` نفّذ:

```bash
gradle wrapper --gradle-version 8.11.1 --distribution-type bin
./gradlew --version
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

في Windows PowerShell استخدم:
```powershell
gradle wrapper --gradle-version 8.11.1 --distribution-type bin
.\gradlew.bat --version
.\gradlew.bat testDebugUnitTest
.\gradlew.bat assembleDebug
```

الناتج المتوقع عند نجاح البناء:
`app/build/outputs/apk/debug/app-debug.apk`

لا تعتبر نجاح أمر إنشاء Wrapper نجاحًا للبناء؛ يجب أن تنجح مهام الاختبار والتجميع أيضًا.

## تشغيل Firebase Emulator محليًا
المتطلبات الرسمية: Node.js 16+ وJava JDK 11+ وFirebase CLI. انظر:
https://firebase.google.com/docs/emulator-suite/install_and_configure

1. افتح مجلد `king_travel_backend_starter`.
2. ثبّت تبعيات وظائف الخادم:
```bash
cd functions
npm install
npm run build
cd ..
```
3. شغّل اختبارات قواعد Firestore:
```bash
firebase emulators:exec --project demo-king-travel --only firestore "npm --prefix functions run test:rules"
```

تم إعداد `firebase.json` بمنافذ محلية:
- Auth: 9099
- Firestore: 8080
- Functions: 5001
- Emulator UI: 4000

أضيفت اختبارات قواعد تشمل:
- منع القراءة دون تسجيل دخول.
- السماح للعميل بقراءة رحلته فقط.
- منع العميل من قراءة رحلة عميل آخر.
- السماح للسائق المعتمد بقراءة الطلب المفتوح والرحلة المسندة إليه.
- منع السائق غير المعتمد أو غير المسند من قراءة رحلة لا تخصه.
- منع العميل من كتابة مستندات الرحلات مباشرة.
- السماح للإدارة بالقراءة.
- استعلامات القوائم المقيدة للعميل والسائق والإدارة، ومنع الاستعلامات غير المقيدة للعميل والسائق.

هذه الاختبارات أُنشئت ولم تُشغّل في هذه البيئة. يجب تشغيلها ومراجعة أي فشل قبل نشر القواعد.

## بناء Cloud Functions واختبارها
بعد نجاح تثبيت الحزم، نفّذ مرة واحدة من مجلد `king_travel_backend_starter`:
```bash
cd functions
npm install
npm run build
cd ..
```

ثم شغّل اختبارات قواعد Firestore الحالية:
```bash
firebase emulators:exec --project demo-king-travel --only firestore "npm --prefix functions run test:rules"
```

**تنبيه:** لا يوجد في `package.json` حاليًا أمر `npm test` ولا حزمة اختبارات تكاملية لوظائف Callable. لا تستخدم أمر `npm test` على أنه اختبار موجود. يلزم إنشاء اختبارات تكاملية منفصلة تغطي إنشاء الحجز، تقديم/اعتماد السائق، قبول رحلة واحدة فقط، إلغاء الرحلة، وانتقالات الحالة، مع إعداد App Check مناسب للاختبار. حتى تُضاف هذه الاختبارات وتنجح، تبقى وظائف Callable غير مثبتة وظيفيًا.

## تحذير منع النشر الفعلي
ملف `.firebaserc` الحالي يشير إلى `king-travel-bf3ba`. لا تستخدم `firebase deploy` أثناء الاختبار. استخدم دائمًا `demo-king-travel` مع Emulator، ولا تنشر إلى المشروع الحقيقي إلا بعد مراجعة القواعد والاختبارات والحصول على موافقة صريحة.
